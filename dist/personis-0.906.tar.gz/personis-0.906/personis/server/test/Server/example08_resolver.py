#!/usr/bin/env python2.4

# NOTE: this test can only be run locally since
# it adds a new resolver.
# - need to dynamically import resolvers on server side

print """
==============================================================
Test of adding new resolver function
this test can only be run locally since it adds a new resolver
see Base tests
==============================================================
"""
import sys; sys.exit(0)

