personis Package
================

Subpackages
-----------

.. toctree::

    personis.client
    personis.server

