client Package
==============

:mod:`client` Package
---------------------

.. automodule:: personis.client
    :members:
    :show-inheritance:

:mod:`util` Module
------------------

.. automodule:: personis.client.util
    :members:
    :show-inheritance:

