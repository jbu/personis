#!/bin/sh

~/google_appengine/appcfg.py --oauth2 update .

