#!/bin/sh
export PYTHONPATH=/home/jbu/personis

python log-llum.py
