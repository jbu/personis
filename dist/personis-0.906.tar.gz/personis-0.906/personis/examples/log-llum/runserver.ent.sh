#!/bin/sh
export PYTHONPATH=/home/jbu/personis/server/Src

python log-llum.py -o oauth.ent.yaml
